import os, sys, traceback
from pathlib import Path
def _main():
    here = Path(sys.executable).resolve().parent
    os.chdir(here)
    sys.path.insert(0, str(here))
    if os.environ.get("YTMP3_SELFTEST") == "1":
        lines = []
        try:
            import tkinter as tk
            import yt_dlp
            import ytmp3.core, ytmp3.requirements
            problems, info = ytmp3.requirements.check_requirements(here)
            lines.append("tk=" + str(tk.TkVersion))
            lines.append("yt_dlp=" + yt_dlp.version.__version__)
            lines.append("problems=" + repr(problems))
            lines.append("info=" + repr(info))
        except Exception:
            lines.append(traceback.format_exc())
        (here / "selftest.txt").write_text(chr(10).join(lines), encoding="utf-8")
        return
    try:
        import runpy
        runpy.run_path(str(here / "app.py"), run_name="__main__")
    except SystemExit:
        raise
    except BaseException:
        (here / "crash.log").write_text(traceback.format_exc(), encoding="utf-8")
        try:
            import tkinter.messagebox as mb
            mb.showerror("YTMP3 gagal dijalankan", traceback.format_exc()[-1200:])
        except Exception:
            pass
try:
    _main()
finally:
    os._exit(0)
